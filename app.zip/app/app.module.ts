import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {BookComponent} from './BookComponent';
import { AppComponent }  from './app.component';
import {FormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';
import {BookListService} from './BookListService';
import {Book} from "./Book";

@NgModule({
  imports:      [BrowserModule,HttpModule,FormsModule],
  declarations: [AppComponent,BookComponent ],
  providers:    [BookListService],
  bootstrap:    [AppComponent ]
})
export class AppModule { }