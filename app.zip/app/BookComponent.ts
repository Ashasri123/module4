import {Component, OnInit} from '@angular/core';
import {Book} from "./Book";
import {BookListService} from './BookListService';
import {Http} from '@angular/http';

@Component({
selector:'app-BookComponent',
templateUrl:'./BookComponent.html',
providers:[BookListService],
})

export class BookComponent implements OnInit{
id:number;
title:string;
year:number;
author:string;
books:Book[];
constructor(private booklistservice:BookListService){}
ngOnInit(){
this.booklistservice.getJSON().subscribe((booksData=>this.books=booksData));
}
delete(obj:Book)
{
var index=this.books.indexOf(obj);
this.books.splice(index,1);
}
addData():void
{
if(this.id!=null&&this.title!=null&&this.year!=null&&this.author!=null)
{
let b:Book={id:this.id,title:this.title,year:this.year,author:this.author};
this.books.push(b);
}
else{
alert("insert data")
}
}
} 